from FW.WEB.base_fw import BaseFW


class AnyPage(BaseFW):
    pass