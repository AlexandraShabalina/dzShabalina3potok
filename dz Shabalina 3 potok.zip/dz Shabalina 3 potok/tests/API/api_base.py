from tests.test_base import TestBase


class ApiBase(TestBase):

    def setup_method(self):
        pass

    def teardown_method(self):
        pass

    def setup_class(self):
        pass

    def teardown_class(self):
        pass