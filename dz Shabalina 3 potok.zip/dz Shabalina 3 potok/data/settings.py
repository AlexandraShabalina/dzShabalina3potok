class Settings:
    url_web = 'https://feature-testing1.gandiva.ru/'
    url_api = 'https://api-feature-testing1.gandiva.ru/'
    url_auth = 'https://auth-feature-testing1.gandiva.ru/'
    access_token = ''
    token_type = ''
    minimal_price = '50000'
    notebook_brand = "Lenovo"
    id = ''
    login = ''
    email = ''
    emailConfirmed = ''
    name = ''
    middleName = ''



    users = {
        "test_user01": {
            "user_id": "28c9a612-cd62-11ec-83a4-8e8a7cded363",
            "secret": "H/r5xm0QmoWZWa8m4ZAWJZGJlSRGfdQSw4ObjK1eIW/DuK1iopUmeh6Su15/sWoq",
        },
        "test_user02": {
            "user_id": "291f50ee-cd62-11ec-b84e-8e8a7cded363",
            "secret": "SI60lu7o6drE7JlzKQXNiFWykCaNMI+bymTdvV8MSspJHsvktINsfjsMkIkli5Xh",
        },
        "test_user03": {
            "user_id": "297076f4-cd62-11ec-a111-8e8a7cded36",
            "secret": "mf0/zENsRwUDzdPeioI9qz+bccv1TaAHd1eLh7juAC/5EsKCf1EXkcTxgiDr8HwS",
        },

    }